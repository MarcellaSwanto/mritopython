
function SaveOutput()

global VImg;
global VCtl;
global VSig;

OutputDir='H:\mritopython-master\output';

fields = {'Mx','My','Mz','Muts','SignalNum'};
VSig = rmfield(VSig,fields);

%The code below saves as both mat and ismrmrd files - can change to only
%have 1 later.
%     save([OutputDir filesep 'Series' num2str(Simuh.ScanSeriesInd)], 'VCtl', 'VSig', 'VImg');
%     save([OutputDir filesep 'Series' num2str(Simuh.ScanSeriesInd)], '-struct', 'Simuh', '*XMLFile', '-append');
%     SeriesName = VCtl.SeriesName;
%     save([OutputDir filesep 'Series' num2str(Simuh.ScanSeriesInd)], 'SeriesName', '-append');
    save([OutputDir filesep 'Series1'], 'VCtl', 'VSig', 'VImg');
%     save(['output' filesep 'Series1'], '-struct', 'Simuh', '*XMLFile', '-append');
    %SeriesName = VCtl.SeriesName;
%     save(['output' filesep 'Series1'], 'SeriesName', '-append');
    

end