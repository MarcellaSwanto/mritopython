
function Plugin_LockK
global VVar

VVar.KzKeeper=VVar.Kz;
VVar.KyKeeper=VVar.Ky;
VVar.KxKeeper=VVar.Kx;


end