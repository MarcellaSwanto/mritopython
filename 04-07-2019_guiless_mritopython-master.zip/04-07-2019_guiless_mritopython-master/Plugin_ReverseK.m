
function Plugin_ReverseK
global VVar

VVar.Kz=-VVar.Kz;
VVar.Ky=-VVar.Ky;
VVar.Kx=-VVar.Kx;


end