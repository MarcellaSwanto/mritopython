function img1 = Localizer(SpinMap)
global VObj;
SelMx = VObj.(char(SpinMap(4))); %SpinMap(4) is 'T2Star'
img1=SelMx(:,:,:,str2double('1'));%img1 is the array containing the T2Star values for every pixel of the image.

end

