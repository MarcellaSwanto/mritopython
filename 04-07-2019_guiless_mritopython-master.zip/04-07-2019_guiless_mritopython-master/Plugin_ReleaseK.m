
function Plugin_ReleaseK
global VVar

VVar.Kz=VVar.KzKeeper;
VVar.Ky=VVar.KyKeeper;
VVar.Kx=VVar.KxKeeper;


end