
function SaveOutput()

global VImg;
global VCtl;
global VSig;

OutputDir='H:\mritopython-master\output';

fields = {'Mx','My','Mz','Muts','SignalNum'};
VSig = rmfield(VSig,fields);

%The code below saves as both mat and ismrmrd files - can change to only
%have 1 later.
save([OutputDir filesep 'Series1'], 'VCtl', 'VSig', 'VImg');
figure
recon_img=imagesc(squeeze(sum(VImg.Mag,4)))%converts the Magnitude in an image, displays it.
    save([OutputDir filesep 'Image1'], 'recon_img');

end