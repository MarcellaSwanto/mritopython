function img2_scanned = Scan(T2StarValue)
global VObj;
global VCtl;
global VMag;
global VCoi;
global VVar;
global VSig;

global VMmg;
global VMco;
global VMgd;


% Preserve VObj VMag
VTmpObj=VObj;
VTmpMag=VMag;

% Create Executing Virtual Structure VOex, VMex
VOex=VObj;
VOex.Rho(repmat(VMag.FRange,  [1,1,1,VObj.TypeNum])==0)=[];
VOex.T1(repmat(VMag.FRange,[1,1,1,VObj.TypeNum])==0)=[];
VOex.T2(repmat(VMag.FRange,[1,1,1,VObj.TypeNum])==0)=[];
VOex.Mz(repmat(VMag.FRange,[1,1,1,VObj.SpinNum,VObj.TypeNum])==0)=[];
VOex.My(repmat(VMag.FRange,[1,1,1,VObj.SpinNum,VObj.TypeNum])==0)=[];
VOex.Mx(repmat(VMag.FRange,[1,1,1,VObj.SpinNum,VObj.TypeNum])==0)=[];

VMex=VMag;
VMex.Gzgrid(VMag.FRange==0)=[];
VMex.Gygrid(VMag.FRange==0)=[];
VMex.Gxgrid(VMag.FRange==0)=[];
VMex.dB0(VMag.FRange==0)=[];
VMex.dWRnd(repmat(VMag.FRange,[1,1,1,VObj.SpinNum,VObj.TypeNum])==0)=[];
VMex.dWRnd(isnan(VMex.dWRnd))=0; % NaN is not supported in C code

% Kernel uses Mz to determine SpinMx size
VOex.Rho=reshape(VOex.Rho,[max(max(sum(VMag.FRange,1))),max(max(sum(VMag.FRange,2))),max(max(sum(VMag.FRange,3))),VObj.TypeNum]);
VOex.T1=reshape(VOex.T1,[max(max(sum(VMag.FRange,1))),max(max(sum(VMag.FRange,2))),max(max(sum(VMag.FRange,3))),VObj.TypeNum]);
VOex.T2=reshape(VOex.T2,[max(max(sum(VMag.FRange,1))),max(max(sum(VMag.FRange,2))),max(max(sum(VMag.FRange,3))),VObj.TypeNum]);
VOex.Mz=reshape(VOex.Mz,[max(max(sum(VMag.FRange,1))),max(max(sum(VMag.FRange,2))),max(max(sum(VMag.FRange,3))),VObj.SpinNum,VObj.TypeNum]);
VOex.Mx=reshape(VOex.Mx,[max(max(sum(VMag.FRange,1))),max(max(sum(VMag.FRange,2))),max(max(sum(VMag.FRange,3))),VObj.SpinNum,VObj.TypeNum]);
VOex.My=reshape(VOex.My,[max(max(sum(VMag.FRange,1))),max(max(sum(VMag.FRange,2))),max(max(sum(VMag.FRange,3))),VObj.SpinNum,VObj.TypeNum]);


VMex.Gzgrid=reshape(VMex.Gzgrid,[max(max(sum(VMag.FRange,1))),max(max(sum(VMag.FRange,2))),max(max(sum(VMag.FRange,3)))]);
VMex.Gxgrid=reshape(VMex.Gxgrid,[max(max(sum(VMag.FRange,1))),max(max(sum(VMag.FRange,2))),max(max(sum(VMag.FRange,3)))]);
VMex.Gygrid=reshape(VMex.Gygrid,[max(max(sum(VMag.FRange,1))),max(max(sum(VMag.FRange,2))),max(max(sum(VMag.FRange,3)))]);
VMex.dB0=reshape(VMex.dB0,[max(max(sum(VMag.FRange,1))),max(max(sum(VMag.FRange,2))),max(max(sum(VMag.FRange,3)))]);
VMex.dWRnd=reshape(VMex.dWRnd,[max(max(sum(VMag.FRange,1))),max(max(sum(VMag.FRange,2))),max(max(sum(VMag.FRange,3))),VObj.SpinNum,VObj.TypeNum]);

[row,col,layer]=size(VOex.Mz);
VVar.ObjLoc = [((col+1)/2)*VOex.XDimRes; ((row+1)/2)*VOex.YDimRes ; ((layer+1)/2)*VOex.ZDimRes]; % Set matrix center as Object position for motion simulation
VVar.ObjTurnLoc = [((col+1)/2)*VOex.XDimRes; ((row+1)/2)*VOex.YDimRes ; ((layer+1)/2)*VOex.ZDimRes]; % Set matrix center as Object origin for motion simulation

VOex.MaxMz = max(VOex.Mz(:));
VOex.MaxMy = max(VOex.My(:));
VOex.MaxMx = max(VOex.Mx(:));
VOex.MaxRho = max(VOex.Rho(:));
VOex.MaxT1 = max(VOex.T1(:));
VOex.MaxT2 = max(VOex.T2(:));
VOex.MaxdWRnd = max(VMex.dWRnd(:));

% Spin execution
VObj=VOex;
VMag=VMex;

% Scan Process
PulseGen(); % Generate Pulse line
VCtl.RunMode=int32(0); % Image scan
DoDataTypeConv(1);

VCtl.MaxThreadNum=8; %Multithreading settings
VCtl.ActiveThreadNum=int32(0);

DoScanAtCPU;  % global (VSeq,VObj,VCtl,VMag,VCoi,VVar,VSig) are needed

DoPostScan();%Adds Noise, reconstructs the image, saves the scan.

% Recover VObj VMag VCoi
VObj=VTmpObj;
VMag=VTmpMag;

end