%Run this function in order to obtain the scan of the chosen phantom.
function mriImage = AllInOneGUILess()
    global VObj;
    global VCtl;
    global VMag;
    global VCoi;
    global VVar;
    global VSig;

    global VMmg;
    global VMco;
    global VMgd;


    spinMap = LoadImage(); %This loads the image from the .mat file into the workspace
    %and extracts the necessary variables into an array
    
    T2StarValue = Localizer(spinMap); %This localizes the image.
    
    PreScan();%Sets the scan parameters, and loads the necessary .xml files for the sequence.
    
    Scan(T2StarValue); %Generates the scan of the image, adds noise,
        %reconstructs the image, and saves the output.
    
end