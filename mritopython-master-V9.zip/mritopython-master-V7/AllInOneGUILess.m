%Note: Make sure the directory for the output folder in the function
%'SaveOutput' is the correct one should the code be downloaded from GitHub
function mriImage = AllInOneGUILess()
    global VObj;
    global VCtl;
    global VMag;
    global VCoi;
    global VVar;
    global VSig;

    global VMmg;
    global VMco;
    global VMgd;

    spinMap = LoadImage(); %This loads the image from the .mat file into the workspace
    %and extracts the necessary variables into an array
    PreScan();
    Scan(); %Gives the following error:

end