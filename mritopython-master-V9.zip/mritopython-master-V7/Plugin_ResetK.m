
function Plugin_ResetK
global VVar

% important data type conversion, has to be done!!!!

VVar.Kz=double(0);
VVar.Ky=double(0);
VVar.Kx=double(0);


end