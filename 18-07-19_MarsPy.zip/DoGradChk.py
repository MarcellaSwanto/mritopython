import numpy as np
def DoGradChk()
    ExecFlag = 1
    GradTolerance = np.absolute(VCtl["MaxGrad"] * 0.01)
    SRTolerance = np.absolute(VCtl["MaxSlewRate"] * 0.01)

    #check Gz
    Flags = VSeq["flagsLine"](2,:)
    tempTuple=np.where(np.not_equal(Flags,0))
    sing=tempTuple[0]
    newList={}
    for i in range (0, len(sing)):
        newList.append( VSeq["tsLine"][sing[i]] )
    t=newList
    dt =  np.diff(t)
    dG =  np.diff(VSeq["GzAmpLine"])
    SlewRate = np.divide(dG,dt)

    # check Gy
    Flags = VSeq["flagsLine"][3,:]
    tempTuple=np.where(np.not_equal(Flags,0))
    sing=tempTuple[0]
    newList={}
    for i in range (0, len(sing)):
        newList.append( VSeq["tsLine"][sing[i]] )
    t=newList
    dt =  np.diff(t)
    dG =  np.diff(VSeq["GyAmpLine"])
    SlewRate = np.divide(dG,dt);

    #check Gx
    Flags = VSeq["flagsLine"][4,:]
    t = VSeq["tsLine"](Flags~=0)
    dt =  np.diff(t)
    dG =  np.diff(VSeq["GxAmpLine"])

SlewRate = np.divide(dG,dt)
return ExecFlag
