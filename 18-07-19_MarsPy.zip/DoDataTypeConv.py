def DoDataTypeConv(Simuh):
    import numpy as np
    # Keep in mind when float data is converted to float, data precision is reduced,
    # sometimes may cause wired rounding error, especially may happen in pulse
    # generation section where two different entry time points mistakenly merge to one.
    # To maintain better calculation accuracy, need to convert data to float
    # type explicitly using float().
    from Scan import VObj
    from Scan import VMag
    from Scan import VCtl
    from Scan import VCoi
    from Scan import VVar
    from Scan import VSig
    from Scan import VSeq
    #Signal Initialization
    SignalNum=numel(find(VSeq["ADCLine"]==1)) #8080
    VSig["Sx"]=float(np.zeros(1,SignalNum*VObj["TypeNum"]*VCoi["RxCoilNum"]))
    VSig["Sy"]=float(np.zeros(1,SignalNum*VObj["TypeNum"]*VCoi["RxCoilNum"]))
    VSig["Kz"]=float(np.zeros(1,SignalNum))
    VSig["Ky"]=float(np.zeros(1,SignalNum))
    VSig["Kx"]=float(np.zeros(1,SignalNum))
    VSig["Mz"]=float32(VSig["Mz"])
    VSig["My"]=float32(VSig["My"])
    VSig["Mx"]=float32(VSig["Mx"])
    VSig["Muts"]=float(VSig["Muts"])
    VSig["SignalNum"]=np.int32(SignalNum)

    #Data Type Conversion
    VObj["Gyro"]=float(VObj["Gyro"])
    VObj["ChemShift"]=float(VObj["ChemShift"])
    VObj["Mz"]=float32(VObj["Mz"])
    VObj["My"]=float32(VObj["My"])
    VObj["Mx"]=float32(VObj["Mx"])
    VObj["Rho"]=float32(VObj["Rho"])
    VObj["T1"]=float32(VObj["T1"])
    VObj["T2"]=float32(VObj["T2"])

    VObj["SpinNum"]=np.int32(VObj["SpinNum"])
    VObj["TypeNum"]=np.int32(VObj["TypeNum"])

    VMag["FRange"]=float(VMag["FRange"])
    VMag["dB0"]=float32(VMag["dB0"])
    VMag["dWRnd"]=float32(VMag["dWRnd"])
    VMag["Gzgrid"]=float32(VMag["Gzgrid"])
    VMag["Gygrid"]=float32(VMag["Gygrid"])
    VMag["Gxgrid"]=float32(VMag["Gxgrid"])

    VCoi["TxCoilmg"]=float32(VCoi["TxCoilmg"])
    VCoi["TxCoilpe"]=float32(VCoi["TxCoilpe"])
    VCoi["RxCoilx"]=float32(VCoi["RxCoilx"])
    VCoi["RxCoily"]=float32(VCoi["RxCoily"])
    VCoi["TxCoilNum"]=np.int32(VCoi["TxCoilNum"])
    VCoi["RxCoilNum"]=np.int32(VCoi["RxCoilNum"])
    VCoi["TxCoilDefault"]=float(VCoi["TxCoilDefault"])
    VCoi["RxCoilDefault"]=float(VCoi["RxCoilDefault"])

    VCtl["CS"]=float(VCtl["CS"])
    VCtl["TRNum"]=np.int32(VCtl["TRNum"])

    VVar["t"]=float(VVar["t"])
    VVar["dt"]=float(VVar["dt"])
    VVar["rfAmp"]=float(VVar["rfAmp"])
    VVar["rfPhase"]=float(VVar["rfPhase"])
    VVar["rfFreq"]=float(VVar["rfFreq"])
    VVar["rfCoil"]=float(VVar["rfCoil"])
    VVar["rfRef"]=float(VVar["rfRef"])
    VVar["GzAmp"]=float(VVar["GzAmp"])
    VVar["GyAmp"]=float(VVar["GyAmp"])
    VVar["GxAmp"]=float(VVar["GxAmp"])
    VVar["ADC"]=float(VVar["ADC"])
    VVar["Ext"]=float(VVar["Ext"])
    VVar["Kz"]=float(VVar["Kz"])
    VVar["Ky"]=float(VVar["Ky"])
    VVar["Kx"]=float(VVar["Kx"])
    VVar["ObjLoc"]=float(VVar["ObjLoc"])
    VVar["ObjTurnLoc"]=float(VVar["ObjTurnLoc"])
    VVar["ObjMotInd"]=float(VVar["ObjMotInd"])
    VVar["ObjAng"]=float(VVar["ObjAng"])
    VVar["gpuFetch"]=float(VVar["gpuFetch"])
    VVar["utsi"]=np.int32(VVar["utsi"])
    VVar["rfi"]=np.int32(VVar["rfi"])
    VVar["Gzi"]=np.int32(VVar["Gzi"])
    VVar["Gyi"]=np.int32(VVar["Gyi"])
    VVar["Gxi"]=np.int32(VVar["Gxi"])
    VVar["ADCi"]=np.int32(VVar["ADCi"])
    VVar["Exti"]=np.int32(VVar["Exti"])
    VVar["SliceCount"]=np.int32(1)
    VVar["PhaseCount"]=np.int32(1)
    VVar["TRCount"]=np.int32(1)

    VSeq["utsLine"]=float(VSeq["utsLine"])
    VSeq["tsLine"]=float(VSeq["tsLine"])
    VSeq["rfAmpLine"]=float(VSeq["rfAmpLine"])
    VSeq["rfPhaseLine"]=float(VSeq["rfPhaseLine"])
    VSeq["rfFreqLine"]=float(VSeq["rfFreqLine"])
    VSeq["rfCoilLine"]=float(VSeq["rfCoilLine"])
    VSeq["GzAmpLine"]=float(VSeq["GzAmpLine"])
    VSeq["GyAmpLine"]=float(VSeq["GyAmpLine"])
    VSeq["GxAmpLine"]=float(VSeq["GxAmpLine"])
    VSeq["ADCLine"]=float(VSeq["ADCLine"])
    VSeq["ExtLine"]=float(VSeq["ExtLine"])
    VSeq["flagsLine"]=float(VSeq["flagsLine"])
