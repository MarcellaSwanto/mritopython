import numpy as np
#returns psd_gre3d dictionary containing rfAmp,rfPhase,rfFreq,rfCoil,GzAmp,GyAmp,GxAmp,ADC,Ext,uts,ts,flags
def PSD_GRE3D():

    # global VCtl
    # global VVar
    CV1=10e-3
    CV10=0
    CV11=0
    CV12=0
    CV13=0
    CV14=0
    CV2=20e-3
    CV3=0
    CV4=0
    CV5=0
    CV6=0
    CV7=0
    CV8=0
    CV9=0
    rfAmpAll=[]
    rfPhaseAll=[]
    rfFreqAll=[]
    rfCoilAll=[]
    GzAmpAll=[]
    GyAmpAll=[]
    GxAmpAll=[]
    ADCAll=[]
    ExtAll=[]
    rfTimeAll=[]
    GzTimeAll=[]
    GyTimeAll=[]
    GxTimeAll=[]
    ADCTimeAll=[]
    ExtTimeAll=[]
    SEtAll=[]
    uts=[]
    ts=[]
    flags=[]
    if VCtl["PlotSeq"] == 1: #it is 0
        rfAmp=[]
        rfPhase=[]
        rfFreq=[]
        rfCoil=[]
        GzAmp=[]
        GyAmp=[]
        GxAmp=[]
        ADC=[]
        Ext=[]
        Freq=1
        Notes ='regular TR section'
        AttributeOpt={'on','off'}
        Switch=AttributeOpt{0}
        TREnd=Inf
        TRStart=1
        tE=VCtl["TR"]
        tS=0
        if VVar["TRCount"]<TRStart or VVar["TRCount"]>TREnd or mod(VVar["TRCount"]-TRStart,Freq)!=0 or Switch=='off':
            #do nothing
        else:
            ts = [ts, tS, tE]
        ts = [0, np.amax(ts)-np.amin(ts)]
        return
    #==============Pulses 1==============
    rfAmp=[]
    rfPhase=[]
    rfFreq=[]
    rfCoil=[]
    GzAmp=[]
    GyAmp=[]
    GxAmp=[]
    ADC=[]
    Ext=[]
    rfTime=[]
    GzTime=[]
    GyTime=[]
    GxTime=[]
    ADCTime=[]
    ExtTime=[]
    Freq=1
    Notes='regular TR section'
    AttributeOpt={'on','off'}
    Switch=AttributeOpt{1}
    TREnd=Inf
    TRStart=1
    tE=VCtl["TR"]
    tS=0
    if tS.size==0 or tE.size==0 or tS>=tE:
    print('SE setting is incorrect for Pulses 1!')
    return
    if VVar["TRCount"]<TRStart or VVar["TRCount"]>TREnd or mod(VVar["TRCount"]-TRStart,Freq)!=0 or Switch=='off'
        #do nothing
    else:
    #    --------------------
    AttributeOpt={'on','off'}
    p["AnchorTE"]=AttributeOpt{1}
    AttributeOpt={'Non','Hamming','Hanning'}
    p["Apod"]=AttributeOpt{1}
    p["CoilID"]=1
    p["DupSpacing"]=0
    p["Duplicates"]=1
    p["FA"]=VCtl["FlipAng"]
    p["Notes"]='excitation rf'
    AttributeOpt={'on','off'}
    p["Switch"]=AttributeOpt{1}
    p["TBP"]=4
    p["dt"]=20e-6
    p["rfFreq"]=0
    p["rfPhase"]=0
    p["tEnd"]=1e-3
    p["tStart"]=0
    if p["Switch"]=='on':
        if p["AnchorTE"]=='on':
            #it seems to always be 'Middle'
                if VCtl["TEAnchor"]=='Start':
                    VCtl["TEAnchorTime"]=p["tStart"]
                if VCtl["TEAnchor"]=='Middle':
                    VCtl["TEAnchorTime"]=(p["tStart"]+p["tEnd"])/2
                if VCtl["TEAnchor"]=='End':
                    VCtl["TEAnchorTime"]=p["tEnd"]
        [rfAmp1,rfPhase1,rfFreq1,rfCoil1,rfTime1]=rfSinc(p)
        if VCtl["MultiTransmit"]=='off':
            if VCtl["MasterTxCoil"]==rfCoil1[1]:
                rfAmp=[rfAmp, rfAmp1]
                rfPhase=[rfPhase, rfPhase1]
                rfFreq=[rfFreq, rfFreq1]
                rfCoil=[rfCoil, rfCoil1]
                rfTime=[rfTime, rfTime1]
            end
        else:
            rfAmp=[rfAmp, rfAmp1]
            rfPhase=[rfPhase, rfPhase1]
            rfFreq=[rfFreq, rfFreq1]
            rfCoil=[rfCoil, rfCoil1]
            rfTime=[rfTime, rfTime1]
    p=[]
    #--------------------
    p["DupSpacing"]=0
    p["Duplicates"]=1
    p["Gz1Sign"]=1
    p["Gz2Sign"]=0
    p["Notes"]='cartesian phase'
    AttributeOpt={'on','off'}
    p["Switch"]=AttributeOpt{1}
    p["t1End"]=CV2
    p['t1Start']=CV1
    p["t2End"]=VCtl["TE"]+CV2
    p["t2Start"]=VCtl["TE"]+CV1
    p["tRamp"]=100e-6
    if p["Switch"]=='on':
        [GzAmp1,GzTime1]=GzCartesian(p)
        GzAmp=[GzAmp, GzAmp1]
        GzTime=[GzTime, GzTime1]
    p=[]
    #--------------------
    p["DupSpacing"]=0
    p["Duplicates"]=1
    p["Gy1Sign"]=1
    p["Gy2Sign"]=0
    p["Notes"]='cartesian phase'
    AttributeOpt={'on','off'}
    p["Switch"]=AttributeOpt{1}
    p["t1End"]=CV2
    p["t1Start"]=CV1
    p["t2End"]=VCtl["TE"]+CV2
    p["t2Start"]=VCtl["TE"]+CV1
    p["tRamp"]=100e-6
    if p["Switch"]=='on':
        [GyAmp1,GyTime1]=GyCartesian(p)
        GyAmp=[GyAmp, GyAmp1]
        GyTime=[GyTime, GyTime1]
    p=[]
    #--------------------
    p["DupSpacing"]=0
    p["Duplicates"]=1
    p["Gx1Sign"]=-1
    p["Gx2Sign"]=1
    p["Gx3Sign"]=0
    p["Notes"]='cartesian frequency'
    AttributeOpt={'on','off'}
    p["Switch"]=AttributeOpt{1}
    p["t1Start"]=CV1
    p["t2Middle"]=VCtl["TE"]
    p["t3Start"]=VCtl["TE"]+CV1
    p["tRamp"]=100e-6
    if p["Switch"]=='on':
        [GxAmp1,GxTime1]=GxCartesian(p)
        GxAmp=[GxAmp, GxAmp1]
        GxTime=[GxTime, GxTime1]
    p=[]
    #--------------------
    p["DupSpacing"]=0
    p["Duplicates"]=1
    p["Notes"]='cartesian readout'
    AttributeOpt={'on','off'}
    p["Switch"]=AttributeOpt{1}
    p["tMiddle"]=VCtl.TE
    if p["Switch"]=='on':
        [ADC1,ADCTime1]=ADCCartesian(p)
        ADC=[ADC, ADC1]
        ADCTime=[ADCTime, ADCTime1]
    p=[]
    #--------------------
    p["DupSpacing"]=0
    p["Duplicates"]=1
    p["Ext"]=1
    p["Notes"]='reset K space location'
    AttributeOpt={'on','off'}
    p["Switch"]=AttributeOpt{1}
    p["tStart"]=CV1/2
    if p["Switch"]=='on':
        [Ext1,ExtTime1]=ExtBit(p)
        Ext=[Ext, Ext1]
        ExtTime=[ExtTime, ExtTime1]
    p=[]
    #--------------------
    p["DupSpacing"]=0
    p["Duplicates"]=1
    p["Ext"]=5
    p["Notes"]='calculate remaining scan time'
    AttributeOpt={'on','off'}
    p["Switch"]=AttributeOpt{1}
    p["tStart"]=0
    if p["Switch"]=='on':
        [Ext2,ExtTime2]=ExtBit(p)
        Ext=[Ext, Ext2]
        ExtTime=[ExtTime, ExtTime2]
    p=[]
    #--------------------
    p["DupSpacing"]=0
    p.["Duplicates"]=1
    p.["Ext"]=8
    p.["Notes"]='trigger object motion'
    AttributeOpt={'on','off'}
    p.["Switch"]=AttributeOpt{1}
    p.["tStart"]=0.1
    if p["Switch"]=='on':
        [Ext3,ExtTime3]=ExtBit(p)
        Ext=[Ext, Ext3]
        ExtTime=[ExtTime, ExtTime3]
    p=[]
    #--------------------
    SEt=[tS, tE]

    #The first two dummy variables are indices array
    #whose elements satisty the conditions
    x1=np.greater(rfTime,SEt[1]-SEt[0])
    x2=np.less(rfTime,0)
    #The third dummy variable is their logical or
    x3=np.logical_or(x1,x2)
    #Initialization of temporary lists
    newlist_rfAmp = []
    newlist_rfPhase = []
    newlist_rfFreq = []
    newlist_rfCoil = []
    newlist_rfTime = []
    for i in range(0,len(x3)):
        if x[i] == False:
            newlist_rfAmp.append(rfAmp[i])
            newlist_rfPhase.append(rfPhase[i])
            newlist_rfFreq.append(rfFreq[i])
            newlist_rfCoil.append(rfCoi[i])
            newlist_rfTime.append(rfTime[i])
    #Updating original variables
    rfAmp = newlist_rfAmp
    rfPhase = newlist_rfPhase
    rfFreq = newlist_rfFreq
    rfCoi = newlist_rfCoil
    rfTime = newlist_rfTime

    # GzAmp[GzTime<0 or GzTime>SEt(1)-SEt(0)] = []
    g1z=np.greater(GzTime,SEt[1]-SEt[0])
    g2z=np.less(GzTime,0)
    g3z=np.logical_or(g1z,g2z)
    newlist_GzAmp = []
    for i1 in range(0, len(g3z)):
        if g3z == False:
            newlist_GzAmp.append(GzAmp[i1])
    GzAmp = newlist_GzAmp

    # GyAmp[GyTime<0 or GyTime>SEt(1)-SEt(0)] = []
    g1y=np.greater(GyTime,SEt[1]-SEt[0])
    g2y=np.less(GyTime,0)
    g3y=np.logical_or(g1y,g2y)
    newlist_GyAmp = []
    for i2 in range(0, len(g3y)):
        if g3y == False:
            newlist_GyAmp.append(GyAmp[i2])
    GyAmp = newlist_GyAmp

    # GxAmp[GxTime<0 or GxTime>SEt(1)-SEt(0)] = []
    g1x=np.greater(GxTime,SEt[1]-SEt[0])
    g2x=np.less(GxTime,0)
    g3x=np.logical_or(g1x,g2x)
    newlist_GxAmp = []
    for i3 in range(0, len(g3x)):
        if g3x == False:
            newlist_GxAmp.append(GxAmp[i3])
    GxAmp = newlist_GxAmp

    # ADC[ADCTime<0 or ADCTime>SEt(1)-SEt(0)] = []
    f1=np.greater(ADCTime, SEt[1]-SEt[0])
    f2=np.less(ADCTime, 0)
    f3=np.logical_or(f1, f2)
    newlist_ADC = []
    for i4 in range(0, len(f3))
        if f3 == False:
            newlist_ADC.append(ADC[i4])
    ADC = newlist_ADC

    # Ext[ExtTime<0 or ExtTime>SEt(1)-SEt(0)] = []
    f_1=np.greater(ExtTime, SEt[1]-SEt[0])
    f_2=np.less(ExtTime, 0)
    f_3=np.logical_or(f_1, f_2)
    newlist_Ext = []
    for i5 in range(0, len(f_3))
        if f_3 == False:
            newlist_Ext.append(Ext[i5])
    Ext = newlist_Ext

    # GzTime[GzTime<0 or GzTime>SEt(1)-SEt(0)] = []
    g4z=np.greater(GzTime, SEt[1]-SEt[0])
    g5z=np.less(GzTime, 0)
    g6z=np.logical_or(g4z, g5z)
    newlist_GzTime = []
    for i6 in range(0, len(g6z))
        if g6z == False:
            newlist_GzTime.append(GzTime[i6])
    GzTime = newlist_GzTime

    # GyTime[GyTime<0 or GyTime>SEt(1)-SEt(0)] = []
    g4y=np.greater(GyTime, SEt[1]-SEt[0])
    g5y=np.less(GyTime, 0)
    g6y=np.logical_or(g4y, g5y)
    newlist_GyTime = []
    for i7 in range(0, len(g6y))
        if g6y == False:
            newlist_GyTime.append(GyTime[i7])
    GyTime = newlist_GyTime

    # GxTime[GxTime<0 or GxTime>SEt(1)-SEt(0)] = []
    g4x=np.greater(GxTime, SEt[1]-SEt[0])
    g5x=np.less(GxTime, 0)
    g6x=np.logical_or(g4x, g5x)
    newlist_GxTime = []
    for i8 in range(0, len(g6x))
        if g6x == False:
            newlist_GxTime.append(GxTime[i8])
    GxTime = newlist_GxTime

    # ADCTime[ADCTime<0 or ADCTime>SEt(1)-SEt(0)] = []
    adc1=np.greater(ADCTime, SEt[1]-SEt[0])
    adc2=np.less(ADCTime, 0)
    adc3=np.logical_or(adc1, adc2)
    newlist_ADCTime = []
    for i9 in range(0, len(adc3))
        if adc3 == False:
            newlist_ADCTime.append(ADCTime[i9])
    ADCTime = newlist_ADCTime

    # ExtTime[ExtTime<0 or ExtTime>SEt(1)-SEt(0)] = []
    et1=np.greater(ExtTime, SEt[1]-SEt[0])
    et2=np.less(ExtTime, 0)
    et3=np.logical_or(et1, et2)
    newlist_Ext = []
    for i0 in range(0, len(et3))
        if et3 == False:
            newlist_Ext.append(Ext[i0])
    ExtTime = newlist_Ext

    # rfAmp[np.absolute(rfAmp)<eps] = 0
    var2=np.absolute(rfAmp)
    rfAmp1=np.greater(eps, var2)
    newlist_rfAmp1 = []
    for ir in range(0, len(rfAmp1))
        if rfAmp1 == True:
            newlist_Ext.append(0)
        else:
            newlist_rfAmp1.append(rfAmp[ir])
    rfAmp = newlist_rfAmp1

    rfTime = rfTime + SEt[0]
    GzTime = GzTime + SEt[0]
    GyTime = GyTime + SEt[0]
    GxTime = GxTime + SEt[0]
    ADCTime = ADCTime + SEt[0]
    ExtTime = ExtTime + SEt[0]
    rfAmpAll=[rfAmpAll, rfAmp]
    rfPhaseAll=[rfPhaseAll, rfPhase]
    rfFreqAll=[rfFreqAll, rfFreq]
    rfCoilAll=[rfCoilAll, rfCoil]
    GzAmpAll=[GzAmpAll, GzAmp]
    GyAmpAll=[GyAmpAll, GyAmp]
    GxAmpAll=[GxAmpAll, GxAmp]
    ADCAll=[ADCAll, ADC]
    ExtAll=[ExtAll, Ext]
    rfTimeAll=[rfTimeAll, rfTime]
    GzTimeAll=[GzTimeAll, GzTime]
    GyTimeAll=[GyTimeAll, GyTime]
    GxTimeAll=[GxTimeAll, GxTime]
    ADCTimeAll=[ADCTimeAll, ADCTime]
    ExtTimeAll=[ExtTimeAll, ExtTime]
    SEtAll=[SEtAll, SEt]

SEflag=np.tile([[0], [0], [0], [0], [0], [0]],[1, 2])
rfflag=np.tile([[1], [0], [0], [0], [0], [0]],[1, max(np.shape(rfTimeAll))])
Gzflag=np.tile([[0], [1], [0], [0], [0], [0]],[1, max(np.shape(GzTimeAll))])
Gyflag=np.tile([[0], [0], [1], [0], [0], [0]],[1, max(np.shape(GyTimeAll))])
Gxflag=np.tile([[0], [0], [0], [1], [0], [0]],[1, max(np.shape(GxTimeAll))])
ADCflag=np.tile([[0], [0], [0], [0], [1], [0]],[1, max(np.shape(ADCTimeAll))])
Extflag=np.tile([[0], [0], [0], [0], [0], [1]],[1, max(np.shape(ExtTimeAll))])

ts=[min(SEtAll), max(SEtAll), rfTimeAll, GzTimeAll, GyTimeAll, GxTimeAll, ADCTimeAll, ExtTimeAll]-min(SEtAll)
flags=[SEflag, rfflag, Gzflag, Gyflag, Gxflag, ADCflag, Extflag]

# [ts,ind]=sort(ts)
ts=np.array(ts)
ind=np.argsort(ts)
ts=ts[ind]

uts=np.unique(ts) #set both to false
flags=flags[:,ind]

# [rfTime,ind]=sort(rfTimeAll-min(SEtAll))
rfTime=np.array(rfTime)
ind=np.argsort(rfTimeAll-min(SEtAll))
temp1=rfTimeAll-min(SEtAll)
rfTime=temp1[ind]

rfAmp=rfAmpAll(:,ind)
rfPhase=rfPhaseAll(:,ind)
rfFreq=rfFreqAll(:,ind)
rfCoil=rfCoilAll(:,ind)

# [GzTime,ind]=sort(GzTimeAll-min(SEtAll))
GzTime=np.array(GzTime)
ind=argsort(GzTimeAll-min(SEtAll))
temp2=GzTimeAll-min(SEtAll)
GzTime=temp2[ind]

GzAmp=GzAmpAll[:,ind]

# [GyTime,ind]=sort(GyTimeAll-min(SEtAll))
GyTime=np.array(GyTime)
ind=argsort(GyTimeAll-min(SEtAll))
temp3=GyTimeAll-min(SEtAll)
GyTime=temp3[ind]

GyAmp=GyAmpAll[:,ind]

# [GxTime,ind]=sort(GxTimeAll-min(SEtAll))
GxTime=np.array(GxTime)
ind=argsort(GxTimeAll-min(SEtAll))
temp4=GxTimeAll-min(SEtAll)
GxTime=temp4[ind]

GxAmp=GxAmpAll[:,ind]

# [ADCTime,ind]=sort(ADCTimeAll-min(SEtAll))
ADCTime=np.array(ADCTime)
ind=argsort(ADCTimeAll-min(SEtAll))
temp5=ADCTimeAll-min(SEtAll)
ADCTime=temp5[ind]

ADC=ADCAll[:,ind]

# [ExtTime,ind]=sort(ExtTimeAll-min(SEtAll))
ExtTime=np.array(ExtTime)
ind=argsort(ExtTimeAll-min(SEtAll))
temp6=ExtTimeAll-min(SEtAll)
ADCTime=temp6[ind]

Ext=ExtAll[:,ind]

rfAmp[0] = 0
rfPhase[0] = 0
rfFreq[0] = 0
GzAmp[0] = 0
GyAmp[0] = 0
GxAmp[0] = 0
ADC[0] = 0
Ext[0] = 0
rfAmp[-1] = 0
rfPhase[-1] = 0
rfFreq[-1] = 0
GzAmp[-1] = 0
GyAmp[-1] = 0
GxAmp[-1] = 0
ADC[-1] = 0
Ext[-1] = 0

dict= {
    "rfAmprfPhase":rfAmprfPhase,
    "rfFreq": rfFreq,
    "rfCoil":rfCoil,
    "GzAmp":GzAmp,
    "GyAmp":GyAmp,
    "GxAmp":GxAmp,
    "ADC":ADC,
    "Ext":Ext,
    "uts":uts,
    "ts":ts,
    "flags":flags
}
return dict
