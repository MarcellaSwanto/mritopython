def DoUpdRateChk():
    import numpy as np

    ExecFlag = 1
    URTolerance = -np.abs(VCtl['MinUpdRate']*0.01)
    #Check update rate
    #check rf
    TxCoilID = np.unique(VSeq['rfCoilLine'], return_index = False, return_inverse = False)

    for i in range(0, len(TxCoilID)):
        Flags = VSeq['flagsLine'][1,:]
        tmpTuple = np.where(np.not_equal(0, Flags))
        sing = tmpTuple[0]
        newlist = []
        for j in range(0, len(sing)):
            newlist.append(VSeq['tsLine'][sing[j]])
        t = newlist
        tmpTuple = np.where(np.equal(VSeq['rfCoilLine'], TxCoilID[i]))
        sing = tmpTuple[0]
        newlist = []
        for j in range(0, len(sing)):
            newlist.append(t[sing[j]])
        t = newlist
        dt = np.diff(t)

        


    return ExecFlag
