import numpy as np
#flag(ind>=0)=1
#original 2 lists
a = [0.2, 0.2, 0.2,-1,-1,-1,0.2,-1]
ind = [3,2.2,1,-90,-3,1,-2, 3]
#list with the true or false values for a certain condition
x = np.greater_equal(ind,0)
print(x)
y = x.ravel().nonzero()
print(y)
newlist = []
#Forming a list with the indices in the ind that are greater than 0+1
for i in range(0,len(y[0])):
    newlist.append(y[0][i]+1)
print(newlist)
#looping through the array with the true or false values
newlist2 = []
for i in range(0,len(a)):
    for j in range(0,len(newlist)):
        if i == newlist[j]:
            newlist2.append(1)
        else:
            newlist2.append(a[i])

a = newlist2
print(a)
#if x[i] == True:
#    newlist.append(1)
#else:
#    newlist.append(a[i])

#a = newlist
