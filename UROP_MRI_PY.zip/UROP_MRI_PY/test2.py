#    VOex.Rho(repmat(VMag.FRange,  [1,1,1,VObj.TypeNum])==0)=[];
import numpy as np
a = [1,2,3]
b =
c = 9
x = np.tile(a,[1,1,1,c])

y = np.equal(x,0)
newlist = []
for i in range(0,len(y)):
    if y[i] == False:
        newlist.append(a[i])
a = newlist
