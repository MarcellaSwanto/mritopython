def Main_function():
    from LoadImage import LoadImage
    from PreScan import PreScan
    from Scan import Scan

    LoadImage()

    PreScan()

    Scan()
    
    return
