
def Scan(VObj,VCtl,VMag,VVar, VSig):
    import numpy as np
    from PulseGen import PulseGen
    from DoDataTypeConv import DoDataTypeConv
    from DoPostScan import DoPostScan

    #Preserve VObj and VMag
    VTmpObj = VObj
    VTmpMag = VMag

    #Create Exectuing Virtual Structure VOex, VMex
    #VOex.Rho(repmat(VMag.FRange,  [1,1,1,VObj.TypeNum])==0)=[];
    #VOex.T1(repmat(VMag.FRange,[1,1,1,VObj.TypeNum])==0)=[];
    #VOex.T2(repmat(VMag.FRange,[1,1,1,VObj.TypeNum])==0)=[];
    #VOex.Mz(repmat(VMag.FRange,[1,1,1,VObj.SpinNum,VObj.TypeNum])==0)=[];
    #VOex.My(repmat(VMag.FRange,[1,1,1,VObj.SpinNum,VObj.TypeNum])==0)=[];
    #VOex.Mx(repmat(VMag.FRange,[1,1,1,VObj.SpinNum,VObj.TypeNum])==0)=[];

    VOex = VObj
    RhoList = []
    T1List = []
    T2List = []
    MzList = []
    MyList = []
    MxList = []
    #This does the repmat function in python
    x = np.tile(VMag['FRange'],[1,1,1,VObj['TypeNum']])
    #This creates a logical array
    y = np.equal(x,0)
    for i in range(0,len(y)):
        if y[i] == False:
            RhoList.append(VOex['Rho'][i])
            T1List.append(VOex['T1'][i])
            T2List.append(VOex['T2'][i])
    x = np.tile(VMag['FRange'],[1,1,1,VObj['SpinNum'],VObj['TypeNum']])
    y = np.equal(x,0)
    for i in range(0,len(y)):
        if y[i] == False:
            MzList.append(VOex['Mz'][i])
            MyList.append(VOex['My'][i])
            MxList.append(VOex['Mx'][i])
    VOex['Rho'] = RhoList
    VOex['T1'] = T1List
    VOex['T2'] = T2List
    VOex['Mz'] = MzList
    VOex['My'] = MyList
    VOex['Mx'] = MxList
    #Get the second group from marcella
    #Kernel uses Mz to determine SpinMx size
    VOex['Rho'] = VOex['Rho'].reshape(np.maximum(np.maximum(np.sum(VMag['FRange'],1))), np.maximum(np.maximum(np.sum(VMag['FRange'],2))),np.maximum(np.maximum(np.sum(VMag['FRange'],3))), VObj['TypeNum'])
    VOex['T1'] = VOex['T1'].reshape(np.maximum(np.maximum(np.sum(VMag['FRange'],1))), np.maximum(np.maximum(np.sum(VMag['FRange'],2))),np.maximum(np.maximum(np.sum(VMag['FRange'],3))), VObj['TypeNum'])
    VOex['T2'] = VOex['T2'].reshape(np.maximum(np.maximum(np.sum(VMag['FRange'],1))), np.maximum(np.maximum(np.sum(VMag['FRange'],2))),np.maximum(np.maximum(np.sum(VMag['FRange'],3))), VObj['TypeNum'])
    VOex['Mz'] = VOex['Mz'].reshape(np.maximum(np.maximum(np.sum(VMag['FRange'],1))), np.maximum(np.maximum(np.sum(VMag['FRange'],2))),np.maximum(np.maximum(np.sum(VMag['FRange'],3))),VObj['SpinNum'] , VObj['TypeNum'])
    VOex['My'] = VOex['My'].reshape(np.maximum(np.maximum(np.sum(VMag['FRange'],1))), np.maximum(np.maximum(np.sum(VMag['FRange'],2))),np.maximum(np.maximum(np.sum(VMag['FRange'],3))),VObj['SpinNum'] , VObj['TypeNum'])
    VOex['Mx'] = VOex['Mx'].reshape(np.maximum(np.maximum(np.sum(VMag['FRange'],1))), np.maximum(np.maximum(np.sum(VMag['FRange'],2))),np.maximum(np.maximum(np.sum(VMag['FRange'],3))),VObj['SpinNum'] , VObj['TypeNum'])



    #Code to find the size of VOex.Mz
    tempTuple = VOex['Mz'].shape()
    row = tempTuple(0)
    col = tempTuple(1)
    layer = tempTuple(2)

    VVar['ObjLoc'] = np.vstack((((col+1)/2)*VOex['XDimRes'],((row+1)/2)*VOex['YDimRes'],((layer+1)/2)*VOex['ZDimRes']))
    VVar['ObjTurnLoc'] = np.vstack((((col+1)/2)*VOex['XDimRes'],((row+1)/2)*VOex['YDimRes'],((layer+1)/2)*VOex['ZDimRes']))

    VOex['MaxMz'] = np.maximum(VOex['Mz'][:])
    VOex['MaxMy'] = np.maximum(VOex['My'][:])
    VOex['MaxMx'] = np.maximum(VOex['Mx'][:])
    VOex['MaxRho'] = np.maximum(VOex['Rho'][:])
    VOex['MaxT1'] = np.maximum(VOex['T1'][:])
    VOex['MaxT2'] = np.maximum(VOex['T2'][:])
    VOex['MaxdWRnd'] = np.maximum(VMex['dWRnd'][:])
    #Spin Execution
    VObj = VOex
    VMag = VMex
    #Scan Process
    PulseGen()
    VCtl['RunMode'] = int32(0)
    DoDataTypeConv(1)
    VCtl['MaxThreadNum'] = 8
    VCtl['ActiveThreadNum'] = np.int32(0)

    DoScanAtCPU()
    DoPostScan()
    VObj = VTmpObj
    VMag = VTmpMag
    return
