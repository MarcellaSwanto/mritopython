
def ADCCartesian(p):
    import numpy as np

    tMiddle = p['tMiddle']
    Duplicates = np.maximum(1, p['Duplicates'])
    DupSpacing = np.maximum(0,p['DupSpacing'])

    #acquisition lobs
    GxAmp = ((1/VCtl['FOVFreq'])/(VObj['Gyro']/(2*math.pi)))*(1/VCtl['BandWidth']
    tHalf = 1/(2*(VObj['Gyro']/(2*math.pi))*GxAmp*VCtl['RFreq'])

    tempDict = StdTrap(tMiddle+VCtl['TEAnchorTime']-tHalf-VCtl['MinUpdRate'],tMiddle+VCtl['TEAnchorTime']+tHalf+VCtl['MinUpdRate'],tMiddle+VCtl['TEAnchorTime']-tHalf,tMiddle+VCtl['TEAnchorTime']+tHalf,1,2,VCtl['ResFreq'],2)
    GAmp1 = tempDict['Grad']
    GTime1 = tempDict['t']

    GAmp = [GAmp1]
    GTime = [GTime1]

    GTime, m, n = np.unique(GTime, return_index = True, return_inverse = True)
    GAmp = GAmp[m]

    #Create Duplicates
