def PulseGen():
    import numpy as np
    from DoGradChk import DoGradChk
    from DoUpdRateChk import DoUpdRateChk
    from PSD_GRE3D import PSD_GRE3D
    
    VCtl['PlotSeq'] = 0
    TmpTR = 10
    TmpFlipAng = VCtl['FlipAng']

    #Pulse and gradient signal generation
    DP = 0
    VVar['SliceCount'] = 0
    VVar['PhaseCount'] = 0
    VVar['TRCount'] = 0
    s = 1
    j = 1

    #PulseGen Loop
    while s<=VCtl['SecondPhNum']:
        VVar['SliceCount'] = s
        while j<=VCtl['FirstPhNum']:
            VVar['PhaseCount'] = j
            VVar['TRCount'] = VVar['TRCount']+1

            tmpDict = PSD_GRE3D()
            rfAmp = tmpDict['rfAmp']
            rfPhase = tmpDict['rfPhase']
            rfFreq = tmpDict['rfFreq']
            rfCoil = tmpDict['rfCoil']
            GzAmp = tmpDict['GzAmp']
            GyAmp = tmpDict['GyAmp']
            GxAmp = tmpDict['GxAmp']
            ADC = tmpDict['ADC']
            Ext = tmpDict['Ext']
            uts = tmpDict['uts']
            ts = tmpDict['ts']
            flags = tmpDict['flags']

            if VVar['TRCount'] ==1 and DP ==0:
                rfAmpLine = rfAmp
                rfPhaseLine = rfPhase
                rfFreqLine = rfFreq
                rfCoilLine = rfCoil
                GzAmpLine = GzAmp
                GyAmpLine = GyAmp
                GxAmpLine = GxAmp
                ADCLine = ADC
                ExtLine = Ext
                utsLine = uts
                tsLine = ts
                flagsLine = flags
            else:
                rfAmpLine[len(rfAmpLine):len(rfAmpLine)-1+len(rfAmp)] = rfAmp
                rfPhaseLine[len(rfPhaseLine):len(rfPhaseLine)-1+len(rfPhase)] = rfPhase
                rfFreqLine[len(rfFreqLine):len(rfFreqLine)-1+len(rfFreq)] = rfFreq
                rfCoilLine[len(rfCoilLine):len(rfCoilLine)-1+len(rfCoil)] = rfCoil
                GzAmpLine[len(GzAmpLine):len(GzAmpLine)-1+len(GzAmp)] = GzAmp
                GyAmpLine[len(GyAmpLine):len(GyAmpLine)-1+len(GyAmp)] = GyAmp
                GxAmpLine[len(GxAmpLine):len(GxAmpLine)-1+len(GxAmp)] = GxAmp
                ADCLine[len(ADCLine):len(ADCLine)-1+len(ADC)] = ADC
                ExtLine[len(ExtLine):len(ExtLine)-1+len(Ext)] = Ext
                utsLine[len(utsLine):len(utsLine)-1+len(uts)] = uts
                tsLine[len(tsLine):len(tsLine)-1+len(ts)] = ts
                flagsLine[len(flagsLine):len(flagsLine)-1+len(flags)] = flags

            j = j+1
        if s==1 and j==1 and DP==1:
            continue
        j = 1
        s = s+1

    VVar['SliceCount'] = 0
    VVar['PhaseCount'] = 0
    VVar['TRCount'] = 0

    VSeq['rfAmpLine'] = rfAmpLine
    VSeq['rfPhaseLine'] = rfPhaseLine
    VSeq['rfFreqLine'] = rfFreqLine
    VSeq['GzAmpLine'] = GzAmpLine
    VSeq['GyAmpLine'] = GyAmpLine
    VSeq['GxAmpLine'] = GxAmpLine
    VSeq['ADCLine'] = ADCLine
    VSeq['ExtLine'] = ExtLine
    VSeq['utsLine'] = utsLine
    VSeq['tsLine'] = tsLine
    VSeq['flagsLine'] = flagsLine

    tmpTuple = rfCoilLine.shape()
    x = tmpTuple[0]
    y = tmpTuple[1]
    z = tmpTuple[2]
    VSeq['rfCoilLine'] = np.ones(x, y, z)# force to convert rfCoilLine
    #to 1 for single Tx - simplified as multi-transmit will always be off

    #Do grad amplitude and slew rate check
    ExecFlag = DoGradChk
    if ExecFlag ==0:
        VSeq = []
        print("Gradient check failed!")

    #Do update rate check
    ExecFlag = DoUpdRateChk
    if ExecFlag ==0:
        VSeq = []
        print("Update rate check failed!")


    return
