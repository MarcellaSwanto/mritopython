def ExtBit(p):
    import numpy as np
    from numpy import array
    from StdBit import StdBit

    #create a Ext signal pulse starting from tStart
    #tStart = Ext signal start time
    #Ext = Ext flag

    #Need to import global VCtl

    tStart = p['tStart']
    Ext = p['Ext']
    Duplicates = np.maximum(1, p['Duplicates'])
    DupSpacing = np.maximum(0, p['DupSpacing'])

    tempdict = StdBit(tStart, tStart+(2*VCtl['MinUpdRate']), Ext)
    Ext = tempdict['Grad']
    ExtTime = tempdict['t']

    #Create Duplicates
    if Duplicates !=1 and DupSpacing != 0:
        Ext = np.tile(Ext, np.array([1, Duplicates])) #Need to check if this will work
        TimeOffset = np.tile(np.arrange(0,((Duplicates-1)*DupSpacing)+1),DupSpacing),np.array([3,1])) #1 was added to the second entry here(the third entry in the matlab code)
        ExtTime = (np.tile(ExtTime, np.array(1, Duplicates)+TimeOffset[:])).conj().transpose

    dict = {'Ext': Ext, 'ExtTime':ExtTime}
    return dict
