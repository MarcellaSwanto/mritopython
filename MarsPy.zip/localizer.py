# def Localizer(SpinMap)
#     #SpinMap is a 6×1 cell array in Matlab
#     global VObj
#     SelMx = VObj.(char(SpinMap[4]))
#     #SelMx is a 3D array 108x90x90
#     # SpinMap(4) is 'T2Star'
#     img1=SelMx(:,:,:,float('1'))
#     # img1 is the array containing the T2Star values for every pixel of the image.
import numpy as np
a = np.zeros((2, 3, 4))
b=a[:,:,1]
print(b)
