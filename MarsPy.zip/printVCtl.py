# # import PreScan
# from PreScan import VObj
# import array
# import numpy as np
#
# # printing=VCtl_func()
# # print(printing["ResFreq"])
# print(VObj["SpinNum"])
import numpy
A=numpy.array([[1,2,3],[4,5,6]])
print(A)
A[range(0,1) ,:]=0
print(A)
