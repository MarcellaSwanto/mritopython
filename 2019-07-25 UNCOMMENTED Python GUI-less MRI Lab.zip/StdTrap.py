import numpy as np

def StdTrap(tStart, tEnd, tUp, tDown, gAmp,sUp, sFlat, sDown):
    import numpy as np
    #tStart = trap start time
    #tEnd = trap end time
    #tUp = time for up Upramp
    #tDown = time for down Upramp
    #s* = increment steps (for up, down and flat)
    #gAmp = trapezoid amplitude

    Grad = []
    t = []

    a = ramp(tStart, tUp, sUp, 0, gAmp) #Note: a is a dictionary. Upramp
    Grad1 = a['Grad']
    gt1 =a['t']

    b = rect(tUp, tDown, sFlat, gAmp) #Flattop
    Grad2 = b['Grad']
    gt2 = b['t']

    c = ramp(tDown, tEnd, sDown, gAmp, 0) #downramp
    Grad3 = c['Grad']
    gt3 = c['t']

    t = np.concatenate((gt1, gt2, gt3), axis=None)
    t, m, n = np.unique(t, return_index = True, return_inverse = True)
    GradTemp = np.concatenate((Grad1, Grad2, Grad3), axis=None)
    Grad = GradTemp[m]
    dict = {'t':t, 'Grad':Grad}
    return dict


def ramp(t1, t2, step, amp1, amp2):
    t = np.linspace(t1, t2, step)
    Grad = np.linspace(amp1, amp2, step)
    dict = {'t':t , 'Grad':Grad}
    return dict

def rect(t1, t2, step, amp):
    t = np.linspace(t1, t2, step)
    Grad = amp*(np.ones(t.shape))
    dict = {'t':t , 'Grad':Grad}
    return dict
