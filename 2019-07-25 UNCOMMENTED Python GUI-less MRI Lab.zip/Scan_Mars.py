VMex=VMag

VMex_GzGrid_z = VMex["Gzgrid"]
VMex_dB0 = VMex["dB0"]
VMex_GyGrid_x = VMex["Gxgrid"]
VMex_GyGrid_y = VMex["Gygrid"]

newlist_VMex_z = []
newlist_VMex_y = []
newlist_VMex_x = []
newlist_dB0 = []

temp = np.equal(VMag["FRange"],0)

for i in range(0, len(temp)):
    if temp[i]==True:

    else
        newlist_VMex_z.append(VMex_GzGrid[i])
        newlist_VMex_y.append(VMex_GyGrid[i])
        newlist_VMex_x.append(VMex_GyGrid[i])
        newlist_VMex_x.append(VMex_dB0[i])

VMex_GzGrid = newlist_VMex_z
VMex_GxGrid = newlist_VMex_x
VMex_GyGrid = newlist_VMex_y
VMex_dB0 = newlist_dB0

#second reshape Block
VMex["Gzgrid"]=np.reshape(VMex["Gzgrid"]np, [max(max(np.sum(VMag["FRange"],3))),max(max(np.sum(VMag["FRange"],1))), max(max(np.sum(VMag["FRange"],2)))])
VMex["Gxgrid"]=np.reshape(VMex["Gxgrid"],[max(max(sum(VMag["FRange"],3))),max(max(sum(VMag["FRange"],1))),max(max(sum(VMag["FRange"],2)))])
VMex.["Gygrid"]=np.reshape(VMex["Gygrid"],[max(max(sum(VMag["FRange"],3))),max(max(sum(VMag["FRange"],1))),max(max(sum(VMag["FRange"],2)))])
VMex["dB0"]=np.reshape(VMex["dB0"],[max(max(sum(VMag["FRange"],3))), max(max(sum(VMag["FRange"],1))),max(max(sum(VMag["FRange"],2)))])
VMex["dWRnd"]=np.reshape(VMex["dWRnd"],[max(max(sum(VMag["FRange"],3))),max(max(sum(VMag["FRange"],1))),max(max(sum(VMag["FRange"],2))),VObj["SpinNum"],VObj["TypeNum"]])
