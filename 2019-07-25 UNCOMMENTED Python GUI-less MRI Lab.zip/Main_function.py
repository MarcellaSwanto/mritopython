import nbimporter
import array
import numpy as np
import nbimporter

def Main_function():
    from Readhdf5 import Readhdf5
    from PreScan import PreScan
    from Scan import Scan

    properties = Readhdf5()
    dictionaries=PreScan(properties)
    Scan(dictionaries)

    return

Main_function()
