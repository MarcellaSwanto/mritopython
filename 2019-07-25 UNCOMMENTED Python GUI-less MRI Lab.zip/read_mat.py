import scipy.io as sio
# mat = scipy.io.loadmat('BrainStandardResolution.mat')
from mat4py import loadmat

# data = loadmat('BrainStandardResolution.mat')
data=sio.loadmat('BrainStandardResolution.mat')

print(data.Type)
