def DoAddNoise:
    #Declaring global variables
    from math import sqrt
    import numpy as np
    #Noise Reference
    BWRef = 1000
    B0Ref = 1.5
    NEXRef = 1
    ADCRef = 10000
    VolRef = 1*(10^-9)
    NoiseRef = 1
    VCtl['NoiseLevel'] = 10
    VCtl['NEX'] = 1
    VCtl['B0'] = 3

    NoiseScale = ( sqrt(VCtl['BandWidth']/BWRef) * ((VCtl['NoiseLevel']/NoiseRef)/(sqrt(VCtl['NEX']/NEXRef))) * (VCtl['B0']/B0Ref) * ((VCtl['RFreq']*VCtl['RPhase']*VCtl['RSlice'])/VolRef) *sqrt((VCtl['ResFreq']*VCtl['ResPhase']*VCtl['SliceNum'])/ADCRef) )

    #The below code is the python version of size() in matlab
    a = VSig['Sx'].shape #This is a tuple
    index1 = a[0]
    index2 = a[1]
    index3 = a[2]
    VSig['Sx'] = NoiseScale*(np.random.randn(index1,index2,index3)) + VSig['Sx']

    b = VSig['Sy'].shape #This is a tuple
    index1 = b[0]
    index2 = b[1]
    index3 = b[2]
    VSig['Sy'] = NoiseScale*(np.random.randn(index1,index2,index3)) + VSig['Sy']
    return
