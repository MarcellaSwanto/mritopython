
function SaveOutput()

global VImg;
global VCtl;
global VSig;

OutputDir='H:\Desktop\mritopython-master-V7\output';

fields = {'Mx','My','Mz','Muts','SignalNum'};
VSig = rmfield(VSig,fields);

figure
imgrecon = imagesc(squeeze(sum(VImg.Mag,4)));
colormap(gray(256))

save([OutputDir filesep 'Series1'], 'VCtl', 'VSig', 'VImg'); 

end